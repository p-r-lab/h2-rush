
import asyncio
import math
import random
import pygame

pygame.init()

# ------------------------------------------------------------
# SETTINGS
# ------------------------------------------------------------
WIDTH, HEIGHT = 800, 650
FPS = 60
TOTAL_HYDROGEN = 32
HYDROGEN_REQUIRED = 24
DIG_RADIUS = 27

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("H2 Rush")
clock = pygame.time.Clock()

# Browser-friendly default fonts
font = pygame.font.Font(None, 28)
small_font = pygame.font.Font(None, 22)
tiny_font = pygame.font.Font(None, 18)
big_font = pygame.font.Font(None, 48)

# ------------------------------------------------------------
# COLORS
# ------------------------------------------------------------
BACKGROUND = (22, 29, 39)
WHITE = (245, 248, 250)
LIGHT_GREY = (190, 200, 210)
DARK_GREY = (55, 65, 75)

SOIL = (110, 80, 50)
SOIL_LIGHT = (137, 99, 58)
SOIL_DARK = (90, 65, 42)

ROCK = (92, 100, 110)
ROCK_LIGHT = (135, 145, 155)
ROCK_DARK = (55, 62, 70)

BLUE = (65, 160, 225)
LIGHT_BLUE = (130, 215, 255)
GREEN = (55, 170, 100)
LIGHT_GREEN = (110, 230, 145)
RED = (185, 55, 55)
LIGHT_RED = (255, 105, 100)
YELLOW = (245, 195, 55)

# ------------------------------------------------------------
# LEVEL GEOMETRY
# ------------------------------------------------------------
fuel_cell_rect = pygame.Rect(310, 25, 180, 65)
fuel_inlet = pygame.Rect(365, 88, 70, 38)
source_rect = pygame.Rect(330, 540, 140, 75)
leak_rect = pygame.Rect(590, 195, 125, 90)
restart_button = pygame.Rect(675, 20, 105, 38)

rocks = [
    pygame.Rect(40, 270, 285, 105),
    pygame.Rect(475, 270, 285, 105),
    pygame.Rect(70, 425, 205, 65),
    pygame.Rect(525, 425, 205, 65),
    pygame.Rect(90, 145, 165, 55),
    pygame.Rect(500, 145, 65, 55),
]

terrain = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)


def draw_lightning(surface, x, y, scale=1.0, color=WHITE):
    points = [
        (x + int(3 * scale), y - int(16 * scale)),
        (x - int(8 * scale), y + int(1 * scale)),
        (x - int(1 * scale), y + int(1 * scale)),
        (x - int(5 * scale), y + int(17 * scale)),
        (x + int(12 * scale), y - int(4 * scale)),
        (x + int(4 * scale), y - int(4 * scale)),
    ]
    pygame.draw.polygon(surface, color, points)


def reset_terrain():
    terrain.fill((0, 0, 0, 0))

    pygame.draw.rect(
        terrain, (*SOIL, 255), (40, 120, WIDTH - 80, 400)
    )

    for _ in range(450):
        x = random.randint(45, WIDTH - 45)
        y = random.randint(125, 515)
        radius = random.randint(2, 6)
        color = random.choice([
            (*SOIL_LIGHT, 255),
            (*SOIL_DARK, 255),
            (120, 85, 48, 255),
        ])
        pygame.draw.circle(terrain, color, (x, y), radius)

    # Central valve corridor
    pygame.draw.rect(
        terrain, (0, 0, 0, 0), pygame.Rect(325, 265, 150, 115)
    )

    # Open side branch toward leak
    pygame.draw.rect(
        terrain, (0, 0, 0, 0), pygame.Rect(425, 220, 175, 45)
    )
    pygame.draw.rect(
        terrain, (0, 0, 0, 0), pygame.Rect(405, 220, 45, 70)
    )

    # Leak itself
    pygame.draw.rect(terrain, (0, 0, 0, 0), leak_rect)

    # Small opening below fuel cell
    pygame.draw.rect(
        terrain, (0, 0, 0, 0), pygame.Rect(355, 115, 90, 20)
    )


def terrain_at(x, y):
    x, y = int(x), int(y)
    if x < 0 or x >= WIDTH or y < 0 or y >= HEIGHT:
        return False
    return terrain.get_at((x, y)).a > 0


def rock_at(x, y):
    point = (int(x), int(y))
    return any(rock.collidepoint(point) for rock in rocks)


def draw_rocks():
    for rock in rocks:
        pygame.draw.rect(screen, ROCK_DARK, rock, border_radius=10)
        inner = rock.inflate(-6, -6)
        pygame.draw.rect(screen, ROCK, inner, border_radius=8)

        pygame.draw.line(
            screen,
            ROCK_LIGHT,
            (inner.left + 15, inner.top + 12),
            (inner.right - 22, inner.top + 12),
            2,
        )

        cx, cy = inner.center
        pygame.draw.line(
            screen, ROCK_DARK, (cx - 20, cy - 4), (cx - 5, cy + 6), 2
        )
        pygame.draw.line(
            screen, ROCK_DARK, (cx - 5, cy + 6), (cx + 8, cy - 2), 2
        )


class Valve:
    def __init__(self):
        self.rect = pygame.Rect(325, 315, 150, 24)
        self.open = False

    def toggle(self):
        self.open = not self.open

    def blocks_point(self, x, y):
        return (not self.open) and self.rect.collidepoint(int(x), int(y))

    def draw(self):
        if self.open:
            gate_color = GREEN
            rim_color = LIGHT_GREEN
            state_text = "OPEN"
            state_color = LIGHT_GREEN
        else:
            gate_color = RED
            rim_color = LIGHT_RED
            state_text = "CLOSED"
            state_color = LIGHT_RED

        pygame.draw.rect(
            screen,
            DARK_GREY,
            (
                self.rect.left - 15,
                self.rect.centery - 8,
                self.rect.width + 30,
                16,
            ),
            border_radius=7,
        )
        pygame.draw.rect(screen, gate_color, self.rect, border_radius=6)
        pygame.draw.rect(screen, rim_color, self.rect, 2, border_radius=6)

        cx, cy = self.rect.center

        pygame.draw.rect(screen, LIGHT_GREY, (cx - 3, cy - 34, 6, 22))
        pygame.draw.circle(screen, DARK_GREY, (cx, cy - 40), 18)
        pygame.draw.circle(screen, LIGHT_GREY, (cx, cy - 40), 18, 3)
        pygame.draw.line(
            screen, LIGHT_GREY, (cx - 13, cy - 40), (cx + 13, cy - 40), 3
        )
        pygame.draw.line(
            screen, LIGHT_GREY, (cx, cy - 53), (cx, cy - 27), 3
        )

        label = small_font.render(state_text, True, state_color)
        screen.blit(
            label,
            (cx - label.get_width() // 2, self.rect.bottom + 8),
        )


valve = Valve()


def solid_at(x, y):
    return terrain_at(x, y) or rock_at(x, y) or valve.blocks_point(x, y)


class Hydrogen:
    def __init__(self):
        self.x = WIDTH // 2 + random.randint(-20, 20)
        self.y = 535
        self.radius = random.randint(6, 9)
        self.rise_speed = random.uniform(68, 92)
        self.side_speed = random.uniform(55, 72)
        self.phase = random.uniform(0, math.pi * 2)
        self.direction = random.choice([-1, 1])

    def collides(self, x, y):
        r = self.radius
        points = [
            (x, y),
            (x - r, y),
            (x + r, y),
            (x, y - r),
            (x, y + r),
            (x - r * 0.7, y - r * 0.7),
            (x + r * 0.7, y - r * 0.7),
        ]
        return any(solid_at(px, py) for px, py in points)

    def update(self, dt):
        # Rise
        new_y = self.y - self.rise_speed * dt
        if not self.collides(self.x, new_y):
            self.y = new_y
        else:
            # Search sideways
            test_x = self.x + self.direction * self.side_speed * dt
            if not self.collides(test_x, self.y):
                self.x = test_x
            else:
                self.direction *= -1
                test_x = self.x + self.direction * self.side_speed * dt
                if not self.collides(test_x, self.y):
                    self.x = test_x

        # Natural wobble
        wobble = math.sin(pygame.time.get_ticks() * 0.003 + self.phase)
        wobble_x = self.x + wobble * 10 * dt
        if not self.collides(wobble_x, self.y):
            self.x = wobble_x

        # Leak suction
        leak_pull_zone = pygame.Rect(415, 155, 330, 195)
        if leak_pull_zone.collidepoint(self.x, self.y):
            if self.x < leak_rect.centerx:
                distance = max(1, leak_rect.centerx - self.x)
                pull_strength = max(20, 60 - distance * 0.08)
                test_x = self.x + pull_strength * dt

                if not self.collides(test_x, self.y):
                    self.x = test_x

    def draw(self):
        pos = (int(self.x), int(self.y))

        pygame.draw.circle(screen, (45, 100, 135), pos, self.radius + 3)
        pygame.draw.circle(screen, (80, 195, 245), pos, self.radius)
        pygame.draw.circle(screen, (215, 245, 255), pos, self.radius, 2)
        pygame.draw.circle(
            screen,
            WHITE,
            (
                int(self.x - self.radius / 3),
                int(self.y - self.radius / 3),
            ),
            2,
        )


class Collectible:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.radius = 18
        self.collected = False

    def check_collision(self, particle):
        if self.collected:
            return

        distance = math.hypot(
            particle.x - self.x,
            particle.y - self.y,
        )

        if distance < self.radius + particle.radius:
            self.collected = True

    def draw(self):
        if self.collected:
            return

        pygame.draw.circle(
            screen, (120, 85, 25), (self.x, self.y), self.radius + 4
        )
        pygame.draw.circle(
            screen, YELLOW, (self.x, self.y), self.radius
        )
        pygame.draw.circle(
            screen,
            (255, 235, 150),
            (self.x, self.y),
            self.radius,
            3,
        )
        draw_lightning(screen, self.x, self.y, 0.65, WHITE)


def create_collectibles():
    return [
        Collectible(400, 455),
        Collectible(395, 235),
        Collectible(305, 170),
    ]


def draw_hydrogen_source():
    x, y, w, h = source_rect

    pygame.draw.ellipse(
        screen, (10, 15, 20), (x + 10, y + h - 3, w - 20, 13)
    )

    pygame.draw.rect(
        screen,
        (35, 115, 190),
        (x + 15, y + 8, w - 30, h - 15),
        border_radius=24,
    )

    pygame.draw.rect(
        screen,
        BLUE,
        (x + 23, y + 12, 22, h - 24),
        border_radius=12,
    )

    pygame.draw.line(
        screen, LIGHT_BLUE, (x + 20, y + 28), (x + w - 20, y + 28), 3
    )
    pygame.draw.line(
        screen,
        LIGHT_BLUE,
        (x + 20, y + h - 24),
        (x + w - 20, y + h - 24),
        3,
    )

    pygame.draw.rect(
        screen,
        LIGHT_GREY,
        (x + w // 2 - 12, y - 7, 24, 14),
        border_radius=4,
    )

    badge_center = (x + w // 2, y + h // 2 + 2)
    pygame.draw.circle(screen, (235, 248, 255), badge_center, 22)

    label = font.render("H2", True, (25, 100, 175))
    screen.blit(
        label,
        (
            badge_center[0] - label.get_width() // 2,
            badge_center[1] - label.get_height() // 2,
        ),
    )


def draw_fuel_cell():
    x, y, w, h = fuel_cell_rect

    pygame.draw.rect(
        screen, (10, 15, 20), (x + 5, y + 5, w, h), border_radius=12
    )

    pygame.draw.rect(screen, DARK_GREY, (x, y, 24, h), border_radius=8)
    pygame.draw.rect(
        screen, DARK_GREY, (x + w - 24, y, 24, h), border_radius=8
    )

    pygame.draw.rect(
        screen,
        (45, 155, 90),
        (x + 20, y + 4, w - 40, h - 8),
        border_radius=8,
    )

    for line_x in range(x + 36, x + w - 30, 16):
        pygame.draw.line(
            screen,
            LIGHT_GREEN,
            (line_x, y + 12),
            (line_x, y + h - 12),
            2,
        )

    pygame.draw.rect(
        screen,
        (210, 235, 220),
        (x + w // 2 - 5, y + 9, 10, h - 18),
        border_radius=4,
    )

    draw_lightning(
        screen, x + w - 47, y + h // 2, 0.8, (255, 225, 80)
    )

    pygame.draw.rect(screen, GREEN, fuel_inlet, border_radius=7)
    pygame.draw.rect(screen, LIGHT_GREEN, fuel_inlet, 2, border_radius=7)

    label = tiny_font.render("H2 IN", True, WHITE)
    screen.blit(
        label,
        (
            fuel_inlet.centerx - label.get_width() // 2,
            fuel_inlet.centery - label.get_height() // 2,
        ),
    )


def draw_leak():
    x, y, w, _ = leak_rect

    pygame.draw.rect(screen, (75, 30, 30), leak_rect, border_radius=14)
    pygame.draw.rect(screen, LIGHT_RED, leak_rect, 3, border_radius=14)

    pipe_y = y + 43

    pygame.draw.rect(
        screen,
        (120, 130, 140),
        (x + 45, pipe_y - 12, 66, 24),
        border_radius=5,
    )

    pygame.draw.ellipse(
        screen, DARK_GREY, (x + 36, pipe_y - 14, 20, 28)
    )
    pygame.draw.ellipse(
        screen, LIGHT_GREY, (x + 38, pipe_y - 11, 13, 22), 2
    )

    crack = [
        (x + 78, pipe_y - 12),
        (x + 72, pipe_y - 3),
        (x + 81, pipe_y + 1),
        (x + 75, pipe_y + 12),
    ]
    pygame.draw.lines(screen, LIGHT_RED, False, crack, 3)

    t = pygame.time.get_ticks() / 500
    bubble_positions = [
        (x + 25, pipe_y - 2),
        (x + 16, pipe_y - 18 + int(math.sin(t) * 3)),
        (x + 8, pipe_y + 8 + int(math.cos(t) * 3)),
        (x + 28, pipe_y + 18),
    ]

    for index, position in enumerate(bubble_positions):
        pygame.draw.circle(
            screen, (125, 205, 245), position, 6 + index % 2, 2
        )

    label = tiny_font.render("H2 LEAK", True, LIGHT_RED)
    screen.blit(
        label,
        (x + w // 2 - label.get_width() // 2, y + 7),
    )


# ------------------------------------------------------------
# GAME STATE
# ------------------------------------------------------------
hydrogen_particles = []
collectibles = create_collectibles()

spawn_timer = 0.0
hydrogen_generated = 0
hydrogen_collected = 0
hydrogen_lost = 0

game_won = False
game_lost = False


def restart_game():
    global hydrogen_particles
    global collectibles
    global spawn_timer
    global hydrogen_generated
    global hydrogen_collected
    global hydrogen_lost
    global game_won
    global game_lost

    hydrogen_particles = []
    collectibles = create_collectibles()

    spawn_timer = 0.0
    hydrogen_generated = 0
    hydrogen_collected = 0
    hydrogen_lost = 0

    game_won = False
    game_lost = False

    valve.open = False
    reset_terrain()


def calculate_efficiency():
    used = hydrogen_collected + hydrogen_lost
    if used == 0:
        return 100
    return int(hydrogen_collected / used * 100)


def calculate_stars():
    if hydrogen_lost <= 2:
        return 3
    if hydrogen_lost <= 5:
        return 2
    return 1


reset_terrain()


# ------------------------------------------------------------
# PYGBAG / BROWSER MAIN LOOP
# ------------------------------------------------------------
async def main():
    global spawn_timer
    global hydrogen_generated
    global hydrogen_collected
    global hydrogen_lost
    global game_won
    global game_lost

    running = True

    while running:
        dt = clock.tick(FPS) / 1000

        # Events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                restart_game()

            if (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
            ):
                if restart_button.collidepoint(event.pos):
                    restart_game()

                elif valve.rect.inflate(55, 70).collidepoint(event.pos):
                    if not game_won and not game_lost:
                        valve.toggle()

        # Digging
        if not game_won and not game_lost:
            buttons = pygame.mouse.get_pressed()

            if buttons[0]:
                mx, my = pygame.mouse.get_pos()
                valve_area = valve.rect.inflate(60, 80)

                if (
                    40 <= mx <= WIDTH - 40
                    and 120 <= my <= 520
                    and not valve_area.collidepoint(mx, my)
                ):
                    pygame.draw.circle(
                        terrain,
                        (0, 0, 0, 0),
                        (mx, my),
                        DIG_RADIUS,
                    )

        # Generate H2
        if (
            not game_won
            and not game_lost
            and hydrogen_generated < TOTAL_HYDROGEN
        ):
            spawn_timer += dt

            if spawn_timer >= 0.32:
                hydrogen_particles.append(Hydrogen())
                hydrogen_generated += 1
                spawn_timer = 0.0

        # Update H2
        for particle in hydrogen_particles[:]:
            particle.update(dt)

            for collectible in collectibles:
                collectible.check_collision(particle)

            expanded_leak = leak_rect.inflate(
                particle.radius * 2,
                particle.radius * 2,
            )

            if expanded_leak.collidepoint(particle.x, particle.y):
                hydrogen_particles.remove(particle)
                hydrogen_lost += 1
                continue

            if fuel_inlet.collidepoint(particle.x, particle.y):
                hydrogen_particles.remove(particle)
                hydrogen_collected += 1
                continue

            if (
                particle.x < -20
                or particle.x > WIDTH + 20
                or particle.y < -20
            ):
                hydrogen_particles.remove(particle)
                hydrogen_lost += 1

        # Game status
        energy_collected = sum(
            1 for item in collectibles if item.collected
        )

        if (
            hydrogen_collected >= HYDROGEN_REQUIRED
            and energy_collected == 3
        ):
            game_won = True

        not_generated = TOTAL_HYDROGEN - hydrogen_generated
        possible_hydrogen = (
            hydrogen_collected
            + len(hydrogen_particles)
            + not_generated
        )

        if possible_hydrogen < HYDROGEN_REQUIRED:
            game_lost = True

        if (
            hydrogen_generated >= TOTAL_HYDROGEN
            and len(hydrogen_particles) == 0
            and not game_won
        ):
            game_lost = True

        # Draw
        screen.fill(BACKGROUND)
        screen.blit(terrain, (0, 0))

        draw_rocks()
        draw_fuel_cell()
        draw_hydrogen_source()
        draw_leak()

        for collectible in collectibles:
            collectible.draw()

        valve.draw()

        for particle in hydrogen_particles:
            particle.draw()

        # UI
        score_text = font.render(
            f"H2 delivered: {hydrogen_collected}/{HYDROGEN_REQUIRED}",
            True,
            WHITE,
        )
        screen.blit(score_text, (18, 18))

        token_text = font.render(
            f"Energy tokens: {energy_collected}/3",
            True,
            (255, 220, 100),
        )
        screen.blit(token_text, (18, 49))

        remaining = TOTAL_HYDROGEN - hydrogen_generated
        remaining_text = small_font.render(
            f"H2 tank: {remaining}",
            True,
            LIGHT_BLUE,
        )
        screen.blit(remaining_text, (18, 82))

        lost_text = small_font.render(
            f"H2 lost: {hydrogen_lost}",
            True,
            LIGHT_RED,
        )
        screen.blit(lost_text, (18, 105))

        pygame.draw.rect(
            screen, (55, 65, 78), restart_button, border_radius=8
        )
        pygame.draw.rect(
            screen, (100, 115, 130), restart_button, 2, border_radius=8
        )

        restart_text = small_font.render("Restart (R)", True, WHITE)
        screen.blit(
            restart_text,
            (
                restart_button.centerx - restart_text.get_width() // 2,
                restart_button.centery - restart_text.get_height() // 2,
            ),
        )

        instruction = small_font.render(
            "Dig soil | Avoid the leak | Click the valve",
            True,
            (215, 220, 225),
        )
        screen.blit(
            instruction,
            (
                WIDTH // 2 - instruction.get_width() // 2,
                HEIGHT - 25,
            ),
        )

        # Win
        if game_won:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 190))
            screen.blit(overlay, (0, 0))

            complete = big_font.render("LEVEL COMPLETE", True, WHITE)
            screen.blit(
                complete,
                (
                    WIDTH // 2 - complete.get_width() // 2,
                    195,
                ),
            )

            efficiency = calculate_efficiency()
            stars = calculate_stars()

            results = [
                (f"H2 delivered: {hydrogen_collected}", WHITE),
                ("Energy tokens: 3 / 3", (255, 220, 100)),
                (f"H2 lost: {hydrogen_lost}", LIGHT_RED),
                (f"Efficiency: {efficiency}%", LIGHT_BLUE),
            ]

            y = 265
            for text, color in results:
                rendered = font.render(text, True, color)
                screen.blit(
                    rendered,
                    (
                        WIDTH // 2 - rendered.get_width() // 2,
                        y,
                    ),
                )
                y += 34

            star_string = "* " * stars + "- " * (3 - stars)
            star_render = big_font.render(star_string, True, YELLOW)

            screen.blit(
                star_render,
                (
                    WIDTH // 2 - star_render.get_width() // 2,
                    415,
                ),
            )

            retry = small_font.render(
                "Press R to play again",
                True,
                LIGHT_GREY,
            )
            screen.blit(
                retry,
                (
                    WIDTH // 2 - retry.get_width() // 2,
                    475,
                ),
            )

        # Lose
        if game_lost and not game_won:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 195))
            screen.blit(overlay, (0, 0))

            fail = big_font.render("LEVEL FAILED", True, LIGHT_RED)
            screen.blit(
                fail,
                (
                    WIDTH // 2 - fail.get_width() // 2,
                    245,
                ),
            )

            reason = font.render(
                "Too much hydrogen was lost.",
                True,
                WHITE,
            )
            screen.blit(
                reason,
                (
                    WIDTH // 2 - reason.get_width() // 2,
                    310,
                ),
            )

            retry = small_font.render(
                "Press R to retry",
                True,
                LIGHT_GREY,
            )
            screen.blit(
                retry,
                (
                    WIDTH // 2 - retry.get_width() // 2,
                    360,
                ),
            )

        pygame.display.flip()

        # Required by Pygbag/browser builds
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
